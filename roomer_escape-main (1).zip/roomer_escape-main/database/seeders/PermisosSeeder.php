<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
//spatie
use Spatie\Permission\Models\Permission;

class PermisosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $permisos = [
        //     //roles
        //     'see-role',
        //     'create-role',
        //     'edit-role',
        //     'delete-role',
        //     //users
        //     'see-user',
        //     'create-user',
        //     'edit-user',
        //     'delete-user'
        // ];

        // foreach ($permisos as $permiso) {
        //     Permission::create(['name' => $permiso]);
        // }
    }
}
